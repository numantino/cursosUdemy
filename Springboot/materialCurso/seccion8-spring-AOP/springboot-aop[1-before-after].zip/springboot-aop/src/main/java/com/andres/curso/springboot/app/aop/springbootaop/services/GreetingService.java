package com.andres.curso.springboot.app.aop.springbootaop.services;

public interface GreetingService {
    String sayHello(String person, String phrase);
}
