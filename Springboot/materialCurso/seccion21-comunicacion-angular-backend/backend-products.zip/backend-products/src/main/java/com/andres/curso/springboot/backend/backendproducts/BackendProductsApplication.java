package com.andres.curso.springboot.backend.backendproducts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendProductsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendProductsApplication.class, args);
	}

}
