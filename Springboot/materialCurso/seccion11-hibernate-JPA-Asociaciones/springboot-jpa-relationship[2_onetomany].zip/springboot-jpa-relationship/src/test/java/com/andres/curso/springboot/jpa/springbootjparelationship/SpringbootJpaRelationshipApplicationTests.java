package com.andres.curso.springboot.jpa.springbootjparelationship;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootJpaRelationshipApplicationTests {

	@Test
	void contextLoads() {
	}

}
