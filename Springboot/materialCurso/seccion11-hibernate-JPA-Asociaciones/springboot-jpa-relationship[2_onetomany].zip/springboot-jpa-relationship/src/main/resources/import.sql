insert into clients (name, lastname) values ('Pepe', 'Doe');
insert into clients (name, lastname) values ('Maria', 'Roe');