insert into clients (name, lastname) values ('Pepe', 'Doe');
insert into clients (name, lastname) values ('Maria', 'Roe');

insert into students (name, lastname) values ('Nacho', 'Goe');
insert into students (name, lastname) values ('Pepa', 'Gon');

insert into courses (name, instructor) values('Curso de Angular', 'Jose');
insert into courses (name, instructor) values('Curso de React', 'Jose');