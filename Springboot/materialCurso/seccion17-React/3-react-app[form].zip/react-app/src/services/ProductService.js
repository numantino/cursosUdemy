
const initProducts = [
    {
        name: 'Monitor Samsung 65',
        price: 500,
        description: 'El monitor es increible!'
    },
    {
        name: 'IPhone 14',
        price: 800,
        description: 'El telefono es muy bueno!'
    }
];

export const listProduct = () => {
    return initProducts; 
}