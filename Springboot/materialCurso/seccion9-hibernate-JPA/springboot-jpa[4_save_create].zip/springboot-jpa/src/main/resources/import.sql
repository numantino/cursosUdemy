INSERT INTO persons (name, lastname, programming_language) VALUES ('Andres', 'Guzman', 'Java');
INSERT INTO persons (name, lastname, programming_language) VALUES ('Pepe', 'Doe', 'Python');
INSERT INTO persons (name, lastname, programming_language) VALUES ('John', 'Dow', 'JavaScript');
INSERT INTO persons (name, lastname, programming_language) VALUES ('Maria', 'Roe', 'Java');
INSERT INTO persons (name, lastname, programming_language) VALUES ('Josefa', 'Rae', 'Java');