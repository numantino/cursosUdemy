package com.andres.curso.springboot.error.springbooterror;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootErrorApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootErrorApplication.class, args);
	}

}
