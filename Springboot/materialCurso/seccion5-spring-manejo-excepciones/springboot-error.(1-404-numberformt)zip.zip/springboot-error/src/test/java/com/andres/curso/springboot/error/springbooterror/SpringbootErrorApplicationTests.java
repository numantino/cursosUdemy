package com.andres.curso.springboot.error.springbooterror;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootErrorApplicationTests {

	@Test
	void contextLoads() {
	}

}
