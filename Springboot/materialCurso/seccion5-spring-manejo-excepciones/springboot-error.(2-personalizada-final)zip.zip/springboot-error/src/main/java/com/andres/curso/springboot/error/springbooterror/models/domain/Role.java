package com.andres.curso.springboot.error.springbooterror.models.domain;

public class Role {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
}
