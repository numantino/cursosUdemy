package com.andres.curso.springboot.calendar.interceptor.springboothorario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootHorarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootHorarioApplication.class, args);
	}

}
