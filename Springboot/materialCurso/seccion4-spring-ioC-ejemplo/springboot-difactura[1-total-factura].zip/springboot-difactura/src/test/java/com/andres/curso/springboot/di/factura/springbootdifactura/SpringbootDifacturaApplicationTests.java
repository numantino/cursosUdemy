package com.andres.curso.springboot.di.factura.springbootdifactura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootDifacturaApplicationTests {

	@Test
	void contextLoads() {
	}

}
